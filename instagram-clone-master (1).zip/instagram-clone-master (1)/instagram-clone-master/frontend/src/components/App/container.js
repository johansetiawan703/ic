import React from "react";
import App from "./presenter";

const Container = props => <App {...props}/>;

export default Container;