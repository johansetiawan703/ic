import React from "react";
import PhotoActions from "./presenter";

const Container = props => <PhotoActions {...props} />;

export default Container;
