import { connect } from "react-redux";
import Container from "./container";

// Add all the actions for:
// Login
// Sign Up
// Recover password
// Check username 
// Check password
// Check email

export default connect()(Container);