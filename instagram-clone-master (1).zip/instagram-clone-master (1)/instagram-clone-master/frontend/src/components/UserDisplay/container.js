import React from "react";
import UserDisplay from "./presenter";

const Container = props => <UserDisplay {...props} />;

export default Container;