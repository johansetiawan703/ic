from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    name = 'sodagram.notifications'
